# CollectiveFund

A TikTok-style vertical swipe platform where people share ideas and collectively fund them. Ideas are presented as full-screen slides that users swipe through one at a time. Each idea can be liked, disliked, or commented on. When enough people like an idea, it moves to a collective funding stage where all interested participants pay an equal share of the total cost.

## Features

### Currently Implemented

1. **TikTok-Style Vertical Feed**
   - Full-screen idea cards that swipe vertically (up/down)
   - Touch gestures, mouse wheel, and keyboard navigation
   - Smooth animations between slides
   - Image carousel within each idea card
   - Vertical dot indicators showing position

2. **Idea Display**
   - Title, creator name, and summary on each card
   - Cost tag showing total funding needed
   - Status tags (Voting / Funded)
   - Background image with gradient overlay

3. **Voting System**
   - Like and Dislike buttons on each idea
   - Animated like button with ripple effect
   - Vote persistence via RESTful API
   - Real-time count updates

4. **Comments**
   - Comment button opens comments screen
   - Add new comments with text input
   - Comments stored in database with timestamps
   - Back navigation to feed

5. **Idea Detail View**
   - Full multi-page idea detail with image gallery
   - Complete description rendering with formatting
   - Funding progress bar
   - Statistics (cost, likes, funders count)
   - Navigation arrows for image gallery

6. **Collective Funding Flow**
   - "Fund This Idea" button on detail screen
   - Equal share calculation based on interested people
   - Funding progress and threshold display
   - Mock payment form (demo)
   - Success confirmation screen with contribution stats

7. **Share New Idea**
   - Form to submit new ideas with title, summary, description, cost, images
   - Post button in header
   - Menu navigation to access the form

8. **Side Menu**
   - Slide-out menu panel
   - Navigation links: Share New Idea, My Ideas, Funded Projects, My Contributions
   - User avatar area

9. **Tab Navigation**
   - "Discover" and "Funded" tabs on main feed
   - Active tab indicator

10. **Responsive Design**
    - Mobile-first layout
    - Desktop constraint to 480px width for app-like feel
    - Touch-optimized buttons and gestures

## Functional Entry Points (Screens)

| Screen | Path | Description |
|--------|------|-------------|
| Main Feed | `index.html` | Vertical swipe feed of all ideas |
| Idea Detail | `#detail` | Full detail view with gallery and stats |
| Comments | `#comments` | Comment thread for current idea |
| Fund Screen | `#fund` | Collective funding contribution page |
| Success | `#success` | Post-funding confirmation |
| New Idea | `#new-idea` | Submit a new idea form |
| Menu | `#menu` | Side navigation panel (overlay) |

## Data Models

### ideas Table
| Field | Type | Description |
|-------|------|-------------|
| id | text | Unique idea ID |
| title | text | Idea title |
| summary | rich_text | Short summary for card view |
| description | rich_text | Full detailed description |
| images | array | Array of image URLs for slides |
| cost | number | Total funding needed |
| status | text | voting, funded, failed, completed |
| creator | text | Creator name |
| likes | number | Like count |
| dislikes | number | Dislike count |
| funded_amount | number | Amount funded so far |
| participants | number | Number of funders |
| created_at | datetime | Creation timestamp |

### votes Table
| Field | Type | Description |
|-------|------|-------------|
| id | text | Unique vote ID |
| idea_id | text | Related idea ID |
| user_id | text | Voter identifier |
| type | text | like or dislike |
| created_at | datetime | Vote timestamp |

### comments Table
| Field | Type | Description |
|-------|------|-------------|
| id | text | Unique comment ID |
| idea_id | text | Related idea ID |
| user_name | text | Commenter name |
| text | rich_text | Comment content |
| created_at | datetime | Comment timestamp |

### funds Table
| Field | Type | Description |
|-------|------|-------------|
| id | text | Unique fund record ID |
| idea_id | text | Related idea ID |
| user_id | text | Funder identifier |
| amount | number | Amount contributed |
| created_at | datetime | Contribution timestamp |

## API Endpoints (Relative)

All data operations use the RESTful Table API:

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `tables/ideas` | List ideas (with pagination, sort, search) |
| GET | `tables/ideas/{id}` | Get single idea |
| POST | `tables/ideas` | Create new idea |
| PUT | `tables/ideas/{id}` | Update idea |
| PATCH | `tables/ideas/{id}` | Partial update |
| DELETE | `tables/ideas/{id}` | Delete idea |

Same pattern applies to `tables/votes`, `tables/comments`, `tables/funds`.

## Demo Data

The project includes 5 pre-seeded ideas:

1. **Solar-Powered Community Charging Station** ($15,000)
2. **Community Garden on Rooftops** ($8,500)
3. **Neighborhood Book Exchange Kiosk** ($3,200)
4. **Open-Air Movie Night Setup** ($12,000)
5. **Community Repair Cafe** ($6,800)

## File Structure

```
index.html          # Main application (single page)
css/
  style.css         # All styles - mobile-first, dark theme
js/
  app.js            # All application logic
```

## Technologies Used

- HTML5 / CSS3 / Vanilla JavaScript (no build step)
- Inter font from Google Fonts
- Font Awesome icons via CDN
- RESTful Table API for data persistence
- LocalStorage for anonymous user ID

## Not Yet Implemented

- Real payment processing integration
- User authentication and accounts
- Push notifications
- Real-time updates via WebSockets
- Image upload (currently requires URLs)
- Search functionality (UI placeholder only)
- "My Ideas" / "My Contributions" filtered views
- Admin moderation tools
- Idea editing and deletion by creators
- Funding deadline/expiration system
- Community voting thresholds with automatic stage transitions

## Recommended Next Steps

1. Add user authentication (OAuth or simple username)
2. Implement real payment integration (Stripe/PayPal)
3. Add image upload with file storage
4. Build search with filters (category, cost range, status)
5. Add "My Ideas" and "My Contributions" views
6. Implement funding thresholds and automatic stage transitions
7. Add push notifications for funding milestones
8. Create admin dashboard for idea moderation
9. Add analytics and reporting for funded projects

## How to Use

1. Open `index.html` in a browser
2. Swipe up/down or use arrow keys to browse ideas
3. Tap Like (heart) or Dislike (X) to vote
4. Tap Info to see full details and gallery
5. Tap Comment to read/add comments
6. In detail view, tap "Fund This Idea" to contribute
7. Use the menu (top left) to share your own idea

## Deployment

This is a static website that can be deployed to any web host. All data is stored via the provided Table API. To deploy, publish using the **Publish tab** in the editor.
