// ===== CollectiveFund App =====

// --- State ---
const AppState = {
    ideas: [],
    currentIndex: 0,
    userId: localStorage.getItem('cf_user_id') || generateId(),
    votes: {},
    comments: {},
    isAnimating: false,
    touchStartY: 0,
    touchStartX: 0,
    currentScreen: 'loading',
    currentIdea: null,
    currentRatings: {}
};

localStorage.setItem('cf_user_id', AppState.userId);

function generateId() {
    return 'user-' + Math.random().toString(36).substring(2, 10);
}

// --- API Helpers (with timeout) ---
function fetchWithTimeout(url, options = {}, timeout = 5000) {
    return Promise.race([
        fetch(url, options),
        new Promise((_, reject) =>
            setTimeout(() => reject(new Error('Request timeout')), timeout)
        )
    ]);
}

async function apiGet(table, id = null, params = '') {
    const url = id ? `tables/${table}/${id}` : `tables/${table}${params}`;
    try {
        const r = await fetchWithTimeout(url);
        if (!r.ok) throw new Error(await r.text());
        return await r.json();
    } catch (e) {
        console.error('GET error:', e);
        throw e;
    }
}

async function apiPost(table, data) {
    try {
        const r = await fetchWithTimeout(`tables/${table}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        if (!r.ok) throw new Error(await r.text());
        return await r.json();
    } catch (e) {
        console.error('POST error:', e);
        throw e;
    }
}

async function apiPatch(table, id, data) {
    try {
        const r = await fetchWithTimeout(`tables/${table}/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        if (!r.ok) throw new Error(await r.text());
        return await r.json();
    } catch (e) {
        console.error('PATCH error:', e);
        throw e;
    }
}

async function apiDelete(table, id) {
    try {
        const r = await fetchWithTimeout(`tables/${table}/${id}`, { method: 'DELETE' });
        if (!r.ok) throw new Error(await r.text());
        return true;
    } catch (e) {
        console.error('DELETE error:', e);
        throw e;
    }
}

// --- Initialization ---
async function init() {
    // Immediately set demo data as fallback so app always works
    AppState.ideas = DEMO_IDEAS;

    // Try to load from API in background
    try {
        await loadIdeas();
    } catch (err) {
        console.log('[Init] API unavailable, using demo data');
        AppState.ideas = DEMO_IDEAS;
    }

    // Always proceed to show the app
    showScreen('feed');
    renderSlides();
    setupEventListeners();
    setupSwipeGestures();
    setupRateScreen();
    setupImagePicker();
}

const DEMO_IDEAS = [
    {
        id: 'demo-1',
        title: 'Solar Charging Station',
        summary: 'A community solar-powered charging hub for electric bikes and phones',
        description: 'We install a solar canopy in the town square with USB-C and bike charging ports.\n\n**Timeline:** 2 weeks\n**Maintenance:** Quarterly cleaning\n**Expected users:** 50+ daily',
        cost: 3500,
        creator: 'Alex M.',
        status: 'voting',
        likes: 42,
        dislikes: 3,
        comments_count: 7,
        funded_amount: 0,
        participants: 0,
        images: ['https://images.unsplash.com/photo-1509391366360-2e959784a276?w=800&q=80'],
        _ratings: [],
        _score: 420
    },
    {
        id: 'demo-2',
        title: 'Community Garden',
        summary: 'Transform the empty lot into raised-bed gardens for everyone',
        description: '20 raised beds, tools shed, drip irrigation, and free workshops for beginners.\n\n**Timeline:** 1 month setup\n**Ongoing:** Volunteer Saturdays\n**Yield:** Seasonal veggies for 40 families',
        cost: 5200,
        creator: 'Sam K.',
        status: 'voting',
        likes: 38,
        dislikes: 2,
        comments_count: 5,
        funded_amount: 0,
        participants: 0,
        images: ['https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800&q=80'],
        _ratings: [],
        _score: 380
    },
    {
        id: 'demo-3',
        title: 'Neighborhood Book Kiosk',
        summary: 'A weatherproof free library box on the corner of Oak and 5th',
        description: 'Little Free Library style kiosk with 50 starter books.\n\n**Maintenance:** Volunteer curators rotate stock\n**Cost:** Materials + initial books\n**Impact:** Encourages reading, reduces waste',
        cost: 800,
        creator: 'Jordan T.',
        status: 'voting',
        likes: 65,
        dislikes: 1,
        comments_count: 12,
        funded_amount: 0,
        participants: 0,
        images: ['https://images.unsplash.com/photo-1521587760476-6c12a4b040da?w=800&q=80'],
        _ratings: [],
        _score: 650
    },
    {
        id: 'demo-4',
        title: 'Outdoor Movie Night Setup',
        summary: 'Portable projector, screen and sound for monthly park screenings',
        description: 'Complete outdoor cinema kit stored at the community center.\n\n**Includes:** 4K projector, 120\" screen, PA speakers\n**Schedule:** Monthly, weather permitting\n**Admission:** Free, popcorn donations welcome',
        cost: 2800,
        creator: 'Riley P.',
        status: 'voting',
        likes: 29,
        dislikes: 4,
        comments_count: 3,
        funded_amount: 0,
        participants: 0,
        images: ['https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800&q=80'],
        _ratings: [],
        _score: 290
    },
    {
        id: 'demo-5',
        title: 'Repair Cafe Toolkit',
        summary: 'Tools and workspace for monthly repair events — fix instead of toss',
        description: 'Soldering stations, sewing machines, bike tools, and basic electronics kit.\n\n**Events:** First Saturday each month\n**Volunteers:** Skilled fixers sign up\n**Goal:** Divert 500kg from landfill yearly',
        cost: 1500,
        creator: 'Morgan L.',
        status: 'funded',
        likes: 78,
        dislikes: 0,
        comments_count: 15,
        funded_amount: 1500,
        participants: 78,
        images: ['https://images.unsplash.com/photo-1581092921461-eab62e97a782?w=800&q=80'],
        _ratings: [],
        _score: 780
    }
];

async function loadIdeas() {
    try {
        const data = await apiGet('ideas', null, '?sort=likes&limit=50');
        let ideas = data && (data.data || data) || [];
        if (!Array.isArray(ideas) || !ideas.length) throw new Error('No ideas from API');
        // Load aggregated ratings for each idea to use in ranking
        ideas = await Promise.all(ideas.map(async (idea) => {
            try {
                const ratingsData = await apiGet('idea_ratings', null, `?idea_id=${idea.id}&limit=100`);
                const ratings = ratingsData && (ratingsData.data || ratingsData) || [];
                idea._ratings = ratings;
                idea._score = calculateIdeaScore(idea, ratings);
            } catch (e) {
                idea._ratings = [];
                idea._score = idea.likes || 0;
            }
            return idea;
        }));
        // Sort by composite score (algorithmic ranking)
        ideas.sort((a, b) => (b._score || 0) - (a._score || 0));
        AppState.ideas = ideas;
    } catch (e) {
        // Fallback to demo data so the app always loads
        console.log('[loadIdeas] Using demo data:', e.message);
        AppState.ideas = DEMO_IDEAS;
    }
}

// Algorithmic scoring: combines likes with criteria ratings
function calculateIdeaScore(idea, ratings) {
    let score = (idea.likes || 0) * 10; // base: 10 points per like
    if (!ratings.length) return score;

    let informedSum = 0, informedCount = 0;
    let effectiveSum = 0, effectiveCount = 0;
    let scaleSum = 0, scaleCount = 0;

    ratings.forEach(r => {
        if (r.informed !== null && r.informed !== undefined) {
            informedSum += r.informed ? 1 : -1;
            informedCount++;
        }
        if (r.effective !== null && r.effective !== undefined) {
            effectiveSum += r.effective ? 1 : -1;
            effectiveCount++;
        }
        if (r.scale_score !== null && r.scale_score !== undefined) {
            scaleSum += parseInt(r.scale_score) || 5;
            scaleCount++;
        }
    });

    if (informedCount > 0) {
        const informedAvg = informedSum / informedCount;
        score += informedAvg > 0 ? 15 : (informedAvg < 0 ? -10 : 0);
    }

    if (effectiveCount > 0) {
        const effectiveAvg = effectiveSum / effectiveCount;
        score += effectiveAvg > 0 ? 20 : (effectiveAvg < 0 ? -15 : 0);
    }

    if (scaleCount > 0) {
        const scaleAvg = scaleSum / scaleCount;
        score += (scaleAvg - 5) * 2;
    }

    return Math.max(0, Math.round(score));
}

// --- Screen Management ---
function showScreen(screenName, data = null) {
    document.querySelectorAll('.screen').forEach(s => {
        s.classList.remove('active');
        s.style.display = 'none';
    });
    const screen = document.getElementById(screenName + '-screen');
    if (screen) {
        screen.style.display = 'flex';
        void screen.offsetWidth;
        screen.classList.add('active');
        AppState.currentScreen = screenName;
    }

    if (screenName === 'detail' && data) renderDetail(data);
    if (screenName === 'comments' && data) renderComments(data);
    if (screenName === 'fund' && data) renderFund(data);
}

// --- Slide Rendering ---
function renderSlides() {
    const wrapper = document.getElementById('slides-wrapper');
    const indicators = document.getElementById('slide-indicators');
    if (!wrapper || !indicators) {
        console.error('[renderSlides] Missing DOM elements');
        return;
    }
    wrapper.innerHTML = '';
    indicators.innerHTML = '';

    if (!AppState.ideas.length) {
        wrapper.innerHTML = '<div style="display:flex;justify-content:center;align-items:center;height:100%;color:#666;text-align:center;padding:2rem;"><div><i class="fas fa-lightbulb" style="font-size:3rem;margin-bottom:1rem;display:block;"></i><h2 style="font-size:1.3rem;margin-bottom:0.5rem;">No ideas yet</h2><p style="font-size:0.9rem;">Be the first to share an idea!</p></div></div>';
        return;
    }

    AppState.ideas.forEach((idea, index) => {
        const slide = document.createElement('div');
        slide.className = `slide ${index === 0 ? 'active' : index < 0 ? 'prev' : 'next'}`;
        if (index > 0) slide.classList.add('next');
        if (index < 0) slide.classList.add('prev');
        slide.dataset.index = index;

        const imgArea = document.createElement('div');
        imgArea.className = 'slide-image-area';
        const images = idea.images && idea.images.length ? idea.images : ['https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=800&q=80'];
        // Build horizontal gallery with track
        imgArea.innerHTML = `
            <div class="slide-images-track" id="track-${index}" data-current="0">
                ${images.map((img, i) => `<img src="${img}" alt="${escapeHtml(idea.title)} ${i + 1}" loading="${index < 2 && i === 0 ? 'eager' : 'lazy'}">`).join('')}
            </div>
            <div class="slide-image-overlay"></div>
            ${images.length > 1 ? `
            <div class="image-indicators">
                ${images.map((_, i) => `<div class="image-indicator ${i === 0 ? 'active' : ''}" data-slide="${index}" data-img="${i}"></div>`).join('')}
            </div>` : ''}
        `;

        const content = document.createElement('div');
        content.className = 'slide-content';
        const costLabel = idea.cost ? formatMoney(idea.cost) : 'TBD';
        const statusLabel = idea.status === 'funded' ? '<span class="slide-tag status-funded">Funded</span>' : '<span class="slide-tag">Voting</span>';

        const ratings = idea._ratings || [];
        let criteriaChips = '';
        if (ratings.length > 0) {
            const informedCount = ratings.filter(r => r.informed === true).length;
            const effectiveCount = ratings.filter(r => r.effective === true).length;
            const scaleRatings = ratings.filter(r => r.scale_score);
            const avgScale = scaleRatings.length ? scaleRatings.reduce((a, r) => a + (parseInt(r.scale_score) || 5), 0) / scaleRatings.length : 5;

            criteriaChips = `<div class="slide-criteria-bar">
                ${informedCount > ratings.length / 2 ? `<span class="criteria-chip"><i class="fas fa-check-circle"></i> Well Informed</span>` : ''}
                ${effectiveCount > ratings.length / 2 ? `<span class="criteria-chip"><i class="fas fa-check-circle"></i> Will Work</span>` : ''}
                ${avgScale >= 7 ? `<span class="criteria-chip"><i class="fas fa-fire"></i> Urgent</span>` : ''}
                <span class="criteria-chip"><i class="fas fa-star"></i> ${ratings.length} rated</span>
            </div>`;
        }

        content.innerHTML = `
            <div class="slide-creator">
                <div class="creator-avatar">${getInitials(idea.creator)}</div>
                <span class="creator-name">${escapeHtml(idea.creator || 'Anonymous')}</span>
            </div>
            <h2 class="slide-title">${escapeHtml(idea.title)}</h2>
            <p class="slide-summary">${escapeHtml(idea.summary || idea.description?.substring(0, 120) + '...' || '')}</p>
            <div class="slide-tags">
                <span class="slide-tag cost">${costLabel}</span>
                ${statusLabel}
            </div>
            ${criteriaChips}
        `;

        slide.appendChild(imgArea);
        slide.appendChild(content);
        wrapper.appendChild(slide);

        const dot = document.createElement('div');
        dot.className = `slide-dot ${index === 0 ? 'active' : ''}`;
        dot.dataset.index = index;
        indicators.appendChild(dot);
    });

    updateActionBar();
}

function updateActionBar() {
    const idea = AppState.ideas[AppState.currentIndex];
    if (!idea) return;

    const likeBtn = document.getElementById('like-btn');
    const dislikeBtn = document.getElementById('dislike-btn');
    const likeCount = document.getElementById('like-count');
    const dislikeCount = document.getElementById('dislike-count');
    const commentCount = document.getElementById('comment-count');
    const rateCount = document.getElementById('rate-count');

    if (!likeBtn || !dislikeBtn) return;

    const vote = AppState.votes[idea.id];
    likeBtn.classList.toggle('active', vote === 'like');
    dislikeBtn.classList.toggle('active', vote === 'dislike');

    if (likeCount) likeCount.textContent = formatNumber(idea.likes || 0);
    if (dislikeCount) dislikeCount.textContent = formatNumber(idea.dislikes || 0);
    if (commentCount) commentCount.textContent = formatNumber(idea.comments_count || 0);
    const ratings = idea._ratings || [];
    if (rateCount) rateCount.textContent = ratings.length > 0 ? ratings.length : '';
}

// --- Swipe Logic ---
function setupSwipeGestures() {
    const container = document.getElementById('swipe-container');
    if (!container) {
        console.error('[setupSwipeGestures] Missing swipe-container');
        return;
    }
    let startY = 0, startX = 0, currentY = 0, isDragging = false;

    container.addEventListener('touchstart', (e) => {
        if (AppState.isAnimating) return;
        startY = e.touches[0].clientY;
        startX = e.touches[0].clientX;
        isDragging = true;
    }, { passive: true });

    container.addEventListener('touchmove', (e) => {
        if (!isDragging || AppState.isAnimating) return;
        const dy = e.touches[0].clientY - startY;
        const dx = e.touches[0].clientX - startX;
        if (Math.abs(dy) > Math.abs(dx)) {
            currentY = dy;
            applyTransform(dy);
        }
    }, { passive: true });

    container.addEventListener('touchend', (e) => {
        if (!isDragging) return;
        isDragging = false;
        const threshold = 80;
        if (currentY < -threshold) {
            navigateSlide(1);
        } else if (currentY > threshold) {
            navigateSlide(-1);
        } else {
            resetTransform();
        }
        currentY = 0;
    });

    let wheelTimeout;
    container.addEventListener('wheel', (e) => {
        e.preventDefault();
        if (AppState.isAnimating) return;
        clearTimeout(wheelTimeout);
        wheelTimeout = setTimeout(() => {
            if (e.deltaY > 30) navigateSlide(1);
            else if (e.deltaY < -30) navigateSlide(-1);
        }, 50);
    }, { passive: false });

    document.addEventListener('keydown', (e) => {
        if (AppState.currentScreen !== 'feed') return;
        if (e.key === 'ArrowDown' || e.key === ' ') navigateSlide(1);
        if (e.key === 'ArrowUp') navigateSlide(-1);
    });
}

function applyTransform(dy) {
    const slides = document.querySelectorAll('.slide');
    const current = slides[AppState.currentIndex];
    if (!current) return;

    // Clear any stale inline styles on ALL slides first
    slides.forEach(slide => {
        slide.style.transition = 'none';
    });

    // Move current slide with finger
    current.style.transform = `translateY(${dy}px)`;

    // Pull adjacent slide into view from its stacked position
    if (dy < 0 && AppState.currentIndex < slides.length - 1) {
        const next = slides[AppState.currentIndex + 1];
        next.style.transform = `translateY(calc(100% + ${dy}px))`;
    } else if (dy > 0 && AppState.currentIndex > 0) {
        const prev = slides[AppState.currentIndex - 1];
        prev.style.transform = `translateY(calc(-100% + ${dy}px))`;
    }
}

function resetTransform() {
    const slides = document.querySelectorAll('.slide');
    slides.forEach((slide, i) => {
        slide.style.transition = '';
        slide.style.transform = '';
        slide.classList.remove('active', 'prev', 'next');
        if (i === AppState.currentIndex) slide.classList.add('active');
        else if (i < AppState.currentIndex) slide.classList.add('prev');
        else slide.classList.add('next');
    });
}

function navigateSlide(direction) {
    if (AppState.isAnimating) return;
    const newIndex = AppState.currentIndex + direction;
    if (newIndex < 0 || newIndex >= AppState.ideas.length) {
        resetTransform();
        return;
    }

    AppState.isAnimating = true;
    const slides = document.querySelectorAll('.slide');

    // CRITICAL: Clear all inline transforms/transitions before class-based animation
    slides.forEach(slide => {
        slide.style.transition = '';
        slide.style.transform = '';
    });

    const current = slides[AppState.currentIndex];
    const target = slides[newIndex];

    if (current && target) {
        current.classList.remove('active');
        current.classList.add(direction > 0 ? 'prev' : 'next');
        target.classList.remove(direction > 0 ? 'next' : 'prev');
        target.classList.add('active');
    }

    document.querySelectorAll('.slide-dot').forEach((dot, i) => {
        dot.classList.toggle('active', i === newIndex);
    });

    AppState.currentIndex = newIndex;
    updateActionBar();

    setTimeout(() => {
        AppState.isAnimating = false;
    }, 400);
}

// --- Safe DOM Helper ---
function safeAdd(id, event, handler) {
    const el = document.getElementById(id);
    if (el) el.addEventListener(event, handler);
}

// --- Event Listeners ---
function setupEventListeners() {

    safeAdd('like-btn', 'click', () => handleVote('like'));
    safeAdd('dislike-btn', 'click', () => handleVote('dislike'));

    safeAdd('comment-btn', 'click', () => {
        const idea = AppState.ideas[AppState.currentIndex];
        if (idea) showScreen('comments', idea);
    });

    safeAdd('rate-btn', 'click', () => {
        const idea = AppState.ideas[AppState.currentIndex];
        if (idea) showRateScreen(idea);
    });

    safeAdd('info-btn', 'click', () => {
        const idea = AppState.ideas[AppState.currentIndex];
        if (idea) showScreen('detail', idea);
    });

    safeAdd('share-btn', 'click', handleShare);

    safeAdd('back-btn', 'click', () => showScreen('feed'));
    safeAdd('comments-back-btn', 'click', () => showScreen('feed'));
    safeAdd('fund-back-btn', 'click', () => showScreen('detail', AppState.currentIdea));
    safeAdd('new-idea-back-btn', 'click', () => showScreen('feed'));

    safeAdd('detail-share-btn', 'click', handleShare);
    safeAdd('fund-btn', 'click', () => {
        if (AppState.currentIdea) showScreen('fund', AppState.currentIdea);
    });

    safeAdd('fund-confirm-btn', 'click', handleFund);
    safeAdd('success-done-btn', 'click', () => showScreen('feed'));

    safeAdd('send-comment-btn', 'click', submitComment);
    safeAdd('comment-input', 'keypress', (e) => {
        if (e.key === 'Enter') submitComment();
    });

    safeAdd('menu-btn', 'click', () => {
        const overlay = document.getElementById('menu-overlay');
        if (overlay) overlay.classList.add('active');
    });
    safeAdd('menu-close', 'click', () => {
        const overlay = document.getElementById('menu-overlay');
        if (overlay) overlay.classList.remove('active');
    });
    safeAdd('menu-overlay', 'click', (e) => {
        if (e.target === e.currentTarget) e.currentTarget.classList.remove('active');
    });

    safeAdd('menu-new-idea', 'click', (e) => {
        e.preventDefault();
        const overlay = document.getElementById('menu-overlay');
        if (overlay) overlay.classList.remove('active');
        showScreen('new-idea');
    });

    safeAdd('submit-idea-btn', 'click', submitIdea);

    safeAdd('search-btn', 'click', () => {
        showToast('Search coming soon!', 'info');
    });

    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            const filter = tab.dataset.tab;
            filterIdeas(filter);
        });
    });
}

// --- Rate Screen ---
function showRateScreen(idea) {
    AppState.currentIdea = idea;
    AppState.currentRatings = {};

    document.getElementById('rate-image').src = idea.images && idea.images[0] ? idea.images[0] : 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=800&q=80';
    document.getElementById('rate-title').textContent = idea.title;

    // Reset UI
    document.querySelectorAll('.criteria-btn').forEach(btn => {
        btn.classList.remove('active-yes', 'active-no');
    });
    document.querySelectorAll('.criteria-expand').forEach(btn => {
        btn.classList.remove('expanded');
    });
    document.querySelectorAll('.criteria-textarea').forEach(el => {
        el.classList.add('hidden');
        const ta = el.querySelector('textarea');
        if (ta) ta.value = '';
    });
    document.getElementById('scale-slider').value = 5;
    document.getElementById('scale-value').textContent = '5';

    loadExistingRating(idea.id);
    showScreen('rate');
}

async function loadExistingRating(ideaId) {
    try {
        const data = await apiGet('idea_ratings', null, `?idea_id=${ideaId}&user_id=${AppState.userId}&limit=1`);
        const ratings = data.data || data || [];
        const existing = ratings[0];
        if (existing) {
            if (existing.informed !== null && existing.informed !== undefined) {
                const val = existing.informed ? 'true' : 'false';
                const btn = document.querySelector(`.criteria-btn[data-criteria="informed"][data-value="${val}"]`);
                if (btn) btn.classList.add(existing.informed ? 'active-yes' : 'active-no');
                if (existing.informed_text) {
                    document.getElementById('informed-text').classList.remove('hidden');
                    document.getElementById('informed-text').querySelector('textarea').value = existing.informed_text;
                    document.querySelector('[data-expand="informed-text"]').classList.add('expanded');
                }
            }
            if (existing.effective !== null && existing.effective !== undefined) {
                const val = existing.effective ? 'true' : 'false';
                const btn = document.querySelector(`.criteria-btn[data-criteria="effective"][data-value="${val}"]`);
                if (btn) btn.classList.add(existing.effective ? 'active-yes' : 'active-no');
                if (existing.effective_text) {
                    document.getElementById('effective-text').classList.remove('hidden');
                    document.getElementById('effective-text').querySelector('textarea').value = existing.effective_text;
                    document.querySelector('[data-expand="effective-text"]').classList.add('expanded');
                }
            }
            if (existing.scale_score !== null && existing.scale_score !== undefined) {
                document.getElementById('scale-slider').value = existing.scale_score;
                document.getElementById('scale-value').textContent = existing.scale_score;
            }
            AppState.currentRatings = {
                informed: existing.informed,
                effective: existing.effective,
                scale_score: existing.scale_score
            };
        }
    } catch (e) {
        // No existing rating
    }
}

function setupRateScreen() {
    document.querySelectorAll('.criteria-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const criteria = btn.dataset.criteria;
            const value = btn.dataset.value === 'true';

            document.querySelectorAll(`.criteria-btn[data-criteria="${criteria}"]`).forEach(b => {
                b.classList.remove('active-yes', 'active-no');
            });
            btn.classList.add(value ? 'active-yes' : 'active-no');

            AppState.currentRatings[criteria] = value;
        });
    });

    document.querySelectorAll('.criteria-expand').forEach(btn => {
        btn.addEventListener('click', () => {
            const targetId = btn.dataset.expand;
            const target = document.getElementById(targetId);
            if (target) {
                target.classList.toggle('hidden');
                btn.classList.toggle('expanded');
            }
        });
    });

    const slider = document.getElementById('scale-slider');
    const scaleValue = document.getElementById('scale-value');
    if (slider && scaleValue) {
        slider.addEventListener('input', () => {
            scaleValue.textContent = slider.value;
        });
    }

    safeAdd('rate-back-btn', 'click', () => showScreen('feed'));
    safeAdd('rate-submit-btn', 'click', submitRating);
}

async function submitRating() {
    const idea = AppState.currentIdea;
    if (!idea) return;

    const informed = AppState.currentRatings.informed !== undefined ? AppState.currentRatings.informed : null;
    const effective = AppState.currentRatings.effective !== undefined ? AppState.currentRatings.effective : null;
    const scale_slider = document.getElementById('scale-slider');
    const scale_score = scale_slider ? scale_slider.value : 5;
    const informed_text_el = document.getElementById('informed-text');
    const effective_text_el = document.getElementById('effective-text');
    const informed_text = informed_text_el && informed_text_el.querySelector('textarea') ? informed_text_el.querySelector('textarea').value.trim() || null : null;
    const effective_text = effective_text_el && effective_text_el.querySelector('textarea') ? effective_text_el.querySelector('textarea').value.trim() || null : null;

    try {
        const existingData = await apiGet('idea_ratings', null, `?idea_id=${idea.id}&user_id=${AppState.userId}&limit=1`);
        const existing = (existingData.data || existingData)[0];

        const payload = {
            idea_id: idea.id,
            user_id: AppState.userId,
            informed,
            effective,
            scale_score,
            informed_text,
            effective_text
        };

        if (existing) {
            await apiPatch('idea_ratings', existing.id, payload);
        } else {
            await apiPost('idea_ratings', payload);
        }

        showToast('Rating submitted!', 'success');
        showScreen('feed');

        const ratingsData = await apiGet('idea_ratings', null, `?idea_id=${idea.id}&limit=100`);
        idea._ratings = ratingsData.data || ratingsData || [];
        idea._score = calculateIdeaScore(idea, idea._ratings);
        renderSlides();
        updateActionBar();
    } catch (e) {
        showToast('Failed to submit rating', 'error');
    }
}

// --- Voting ---
async function handleVote(type) {
    const idea = AppState.ideas[AppState.currentIndex];
    if (!idea) return;

    const currentVote = AppState.votes[idea.id];
    let newLikes = idea.likes || 0;
    let newDislikes = idea.dislikes || 0;

    if (currentVote === type) {
        delete AppState.votes[idea.id];
        if (type === 'like') newLikes--;
        else newDislikes--;
    } else {
        if (currentVote === 'like') newLikes--;
        if (currentVote === 'dislike') newDislikes--;
        AppState.votes[idea.id] = type;
        if (type === 'like') newLikes++;
        else newDislikes++;
    }

    idea.likes = Math.max(0, newLikes);
    idea.dislikes = Math.max(0, newDislikes);
    updateActionBar();

    const btn = document.getElementById(type + '-btn');
    btn.classList.toggle('active', AppState.votes[idea.id] === type);
    if (type === 'like' && AppState.votes[idea.id] === 'like') {
        const ripple = document.createElement('div');
        ripple.className = 'like-ripple';
        btn.appendChild(ripple);
        setTimeout(() => ripple.remove(), 500);
    }

    try {
        const voteData = await apiGet('votes', null, `?idea_id=${idea.id}&user_id=${AppState.userId}`);
        const existing = (voteData.data || voteData)[0];

        if (!AppState.votes[idea.id]) {
            if (existing) await apiDelete('votes', existing.id);
        } else if (existing) {
            await apiPatch('votes', existing.id, { type });
        } else {
            await apiPost('votes', {
                idea_id: idea.id,
                user_id: AppState.userId,
                type
            });
        }

        await apiPatch('ideas', idea.id, { likes: idea.likes, dislikes: idea.dislikes });
    } catch (e) {
        // Silently fail
    }
}

// --- Comments ---
async function loadComments(ideaId) {
    try {
        const data = await apiGet('comments', null, `?idea_id=${ideaId}&limit=100`);
        AppState.comments[ideaId] = data.data || data || [];
    } catch (e) {
        AppState.comments[ideaId] = [];
    }
}

async function renderComments(idea) {
    await loadComments(idea.id);
    const list = document.getElementById('comments-list');
    const comments = AppState.comments[idea.id] || [];

    document.getElementById('comments-count').textContent = comments.length;

    if (!comments.length) {
        list.innerHTML = `
            <div class="empty-comments">
                <i class="fas fa-comment-dots"></i>
                <p>No comments yet. Be the first!</p>
            </div>
        `;
        return;
    }

    list.innerHTML = comments.map(c => `
        <div class="comment-item">
            <div class="comment-header">
                <div class="comment-avatar">${getInitials(c.user_name)}</div>
                <div class="comment-meta">
                    <div class="comment-author">${escapeHtml(c.user_name)}</div>
                    <div class="comment-time">${timeAgo(c.created_at)}</div>
                </div>
            </div>
            <div class="comment-text">${escapeHtml(c.text)}</div>
        </div>
    `).join('');
}

async function submitComment() {
    const input = document.getElementById('comment-input');
    const text = input.value.trim();
    if (!text) return;

    const idea = AppState.currentIdea || AppState.ideas[AppState.currentIndex];
    if (!idea) return;

    try {
        await apiPost('comments', {
            idea_id: idea.id,
            user_name: 'Guest User',
            text
        });
        input.value = '';
        // Increment local comment count so UI updates immediately
        idea.comments_count = (idea.comments_count || 0) + 1;
        updateActionBar();
        await renderComments(idea);
        showToast('Comment posted!', 'success');
    } catch (e) {
        showToast('Failed to post comment', 'error');
    }
}

// --- Detail Screen ---
function renderDetail(idea) {
    AppState.currentIdea = idea;

    document.getElementById('detail-title').textContent = 'Idea Details';
    const content = document.getElementById('detail-content');

    const images = idea.images || [];
    const imgHtml = images.length ? `
        <div class="detail-gallery" id="detail-gallery">
            ${images.map((img, i) => `<img src="${img}" class="${i === 0 ? 'active' : ''}" alt="">`).join('')}
            <div class="gallery-nav">
                ${images.map((_, i) => `<div class="gallery-dot ${i === 0 ? 'active' : ''}" data-index="${i}"></div>`).join('')}
            </div>
            <div class="gallery-arrows">
                <button class="gallery-arrow" id="gallery-prev"><i class="fas fa-chevron-left"></i></button>
                <button class="gallery-arrow" id="gallery-next"><i class="fas fa-chevron-right"></i></button>
            </div>
        </div>
    ` : '';

    const fundedPercent = idea.cost && idea.funded_amount ? Math.round((idea.funded_amount / idea.cost) * 100) : 0;

    content.innerHTML = `
        ${imgHtml}
        <div class="detail-info">
            <h1 class="detail-title">${escapeHtml(idea.title)}</h1>
            <div class="detail-creator">
                <div class="creator-avatar" style="width:24px;height:24px;font-size:0.7rem;">${getInitials(idea.creator)}</div>
                <span>${escapeHtml(idea.creator || 'Anonymous')}</span>
            </div>
            <div class="detail-description">${formatDescription(idea.description || idea.summary || '')}</div>
            <div class="detail-stats">
                <div class="detail-stat">
                    <span class="detail-stat-value">${formatMoney(idea.cost || 0)}</span>
                    <span class="detail-stat-label">Total Cost</span>
                </div>
                <div class="detail-stat">
                    <span class="detail-stat-value">${idea.likes || 0}</span>
                    <span class="detail-stat-label">Likes</span>
                </div>
                <div class="detail-stat">
                    <span class="detail-stat-value">${idea.participants || 0}</span>
                    <span class="detail-stat-label">Funders</span>
                </div>
            </div>
            <div class="funding-progress">
                <h4><i class="fas fa-chart-line"></i> Funding Progress</h4>
                <div class="progress-bar-bg">
                    <div class="progress-bar-fill" style="width: ${fundedPercent}%"></div>
                </div>
                <div class="progress-text">
                    <span>${formatMoney(idea.funded_amount || 0)} raised</span>
                    <span>${fundedPercent}% of ${formatMoney(idea.cost || 0)}</span>
                </div>
            </div>
            ${idea.status === 'voting' ? `
            <div style="background:rgba(99,102,241,0.1);padding:1rem;border-radius:var(--radius-sm);margin-bottom:1rem;">
                <p style="font-size:0.85rem;color:var(--text-muted);line-height:1.6;">
                    <i class="fas fa-info-circle" style="color:var(--primary);margin-right:0.3rem;"></i>
                    This idea needs more likes to reach the funding stage. Like it to show your support!
                </p>
            </div>` : ''}
        </div>
    `;

    if (images.length > 1) {
        let currentImg = 0;
        const updateGallery = () => {
            document.querySelectorAll('#detail-gallery img').forEach((img, i) => {
                img.classList.toggle('active', i === currentImg);
            });
            document.querySelectorAll('.gallery-dot').forEach((dot, i) => {
                dot.classList.toggle('active', i === currentImg);
            });
        };
        document.getElementById('gallery-prev').addEventListener('click', () => {
            currentImg = (currentImg - 1 + images.length) % images.length;
            updateGallery();
        });
        document.getElementById('gallery-next').addEventListener('click', () => {
            currentImg = (currentImg + 1) % images.length;
            updateGallery();
        });
        document.querySelectorAll('.gallery-dot').forEach(dot => {
            dot.addEventListener('click', () => {
                currentImg = parseInt(dot.dataset.index);
                updateGallery();
            });
        });
    }
}

// --- Fund Screen ---
function renderFund(idea) {
    AppState.currentIdea = idea;

    document.getElementById('fund-image').src = idea.images && idea.images[0] ? idea.images[0] : 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=800&q=80';
    document.getElementById('fund-title').textContent = idea.title;
    document.getElementById('fund-summary').textContent = idea.summary || '';
    document.getElementById('fund-total-cost').textContent = formatMoney(idea.cost || 0);

    const interested = idea.likes || 0;
    document.getElementById('fund-interested').textContent = interested;

    const share = interested > 0 ? Math.ceil((idea.cost || 0) / interested) : 0;
    document.getElementById('fund-share').textContent = formatMoney(share);
    document.getElementById('fund-confirm-amount').textContent = formatMoney(share);

    const threshold = 50;
    const progress = Math.min(100, (interested / threshold) * 100);
    document.getElementById('vote-progress-fill').style.width = progress + '%';
    document.getElementById('vote-progress-text').textContent =
        `${interested} likes - Needs ${Math.max(0, threshold - interested)} more to reach funding threshold`;
}

async function handleFund() {
    const idea = AppState.currentIdea;
    if (!idea) return;

    const interested = idea.likes || 1;
    const share = interested > 0 ? Math.ceil((idea.cost || 0) / interested) : 0;

    try {
        const newFunded = (idea.funded_amount || 0) + share;
        const newParticipants = (idea.participants || 0) + 1;

        await apiPost('funds', {
            idea_id: idea.id,
            user_id: AppState.userId,
            amount: share
        });

        await apiPatch('ideas', idea.id, {
            funded_amount: newFunded,
            participants: newParticipants,
            status: newFunded >= idea.cost ? 'completed' : (newFunded > 0 ? 'funded' : idea.status)
        });

        idea.funded_amount = newFunded;
        idea.participants = newParticipants;

        document.getElementById('success-message').textContent =
            `You contributed ${formatMoney(share)} to ${idea.title}.`;
        document.getElementById('success-total').textContent = formatMoney(newFunded);
        document.getElementById('success-participants').textContent = newParticipants;
        showScreen('success');
    } catch (e) {
        document.getElementById('success-message').textContent =
            `You contributed ${formatMoney(share)} to ${idea.title}. (Demo mode)`;
        document.getElementById('success-total').textContent = formatMoney((idea.funded_amount || 0) + share);
        document.getElementById('success-participants').textContent = (idea.participants || 0) + 1;
        showScreen('success');
    }
}

// --- New Idea ---
async function submitIdea() {
    const title = document.getElementById('new-title').value.trim();
    const summary = document.getElementById('new-summary').value.trim();
    const description = document.getElementById('new-description').value.trim();
    const cost = parseFloat(document.getElementById('new-cost').value) || 0;
    const imagesRaw = document.getElementById('new-images').value.trim();

    if (!title || !summary) {
        showToast('Please fill in title and summary', 'error');
        return;
    }

    const images = imagesRaw ? imagesRaw.split('\n').map(s => s.trim()).filter(Boolean) : [];

    try {
        const idea = await apiPost('ideas', {
            title,
            summary,
            description,
            cost,
            images,
            status: 'voting',
            creator: 'Guest User',
            likes: 0,
            dislikes: 0,
            comments_count: 0,
            funded_amount: 0,
            participants: 0
        });

        showToast('Idea posted!', 'success');
        showScreen('feed');

        AppState.ideas.unshift(idea);
        AppState.currentIndex = 0;
        renderSlides();
    } catch (e) {
        showToast('Failed to post idea', 'error');
    }
}

// --- Filters ---
function filterIdeas(filter) {
    if (filter === 'funded') {
        AppState.ideas.sort((a, b) => (b.funded_amount || 0) - (a.funded_amount || 0));
    } else {
        AppState.ideas.sort((a, b) => (b._score || b.likes || 0) - (a._score || a.likes || 0));
    }
    AppState.currentIndex = 0;
    renderSlides();
}

// --- Share ---
async function handleShare() {
    const idea = AppState.currentIdea || AppState.ideas[AppState.currentIndex];
    if (!idea) return;

    const url = `${window.location.origin}?idea=${idea.id}`;

    if (navigator.share) {
        try {
            await navigator.share({
                title: idea.title,
                text: idea.summary,
                url
            });
        } catch (e) {
            // Cancelled
        }
    } else {
        try {
            await navigator.clipboard.writeText(url);
            showToast('Link copied to clipboard!', 'success');
        } catch (e) {
            showToast('Share feature coming soon', 'info');
        }
    }
}

// --- Toast ---
function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    const icon = type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle';
    toast.innerHTML = `<i class="fas fa-${icon}"></i> <span>${escapeHtml(message)}</span>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

// --- Utilities ---
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatMoney(amount) {
    return '$' + (amount || 0).toLocaleString();
}

function formatNumber(n) {
    if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
    if (n >= 1000) return (n / 1000).toFixed(1) + 'k';
    return n.toString();
}

function getInitials(name) {
    if (!name) return '?';
    return name.split(' ').map(p => p[0]).join('').toUpperCase().substring(0, 2);
}

function formatDescription(text) {
    if (!text) return '';
    return escapeHtml(text)
        .replace(/\n/g, '<br>')
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
}

function timeAgo(timestamp) {
    if (!timestamp) return 'just now';
    const seconds = Math.floor((Date.now() - new Date(timestamp).getTime()) / 1000);
    if (seconds < 60) return 'just now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
}

// --- Image Picker ---
const PRESET_IMAGES = [
    { url: 'https://images.unsplash.com/photo-1509391366360-2e959784a276?w=800&q=80', label: 'Solar' },
    { url: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800&q=80', label: 'Garden' },
    { url: 'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?w=800&q=80', label: 'Library' },
    { url: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800&q=80', label: 'Cinema' },
    { url: 'https://images.unsplash.com/photo-1581092921461-eab62e97a782?w=800&q=80', label: 'Tools' },
    { url: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=800&q=80', label: 'Community' },
    { url: 'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=800&q=80', label: 'Park' },
    { url: 'https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?w=800&q=80', label: 'Energy' },
    { url: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=800&q=80', label: 'People' }
];

function setupImagePicker() {
    const grid = document.getElementById('preset-grid');
    if (!grid) return;
    grid.innerHTML = PRESET_IMAGES.map((p, i) => `
        <div class="preset-img" data-index="${i}" data-url="${p.url}">
            <img src="${p.url}" alt="${p.label}">
        </div>
    `).join('');

    // Tab switching
    document.querySelectorAll('.picker-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.picker-tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            const panel = tab.dataset.tab;
            document.querySelectorAll('.picker-panel').forEach(p => p.classList.remove('active'));
            document.querySelector(`[data-panel="${panel}"]`).classList.add('active');
        });
    });

    // Preset selection
    let selectedPreset = null;
    grid.addEventListener('click', (e) => {
        const item = e.target.closest('.preset-img');
        if (!item) return;
        document.querySelectorAll('.preset-img').forEach(el => el.classList.remove('selected'));
        item.classList.add('selected');
        selectedPreset = item.dataset.url;
        document.getElementById('new-images').value = selectedPreset;
    });

    // URL input
    const urlInput = document.getElementById('image-url-input');
    if (urlInput) {
        urlInput.addEventListener('input', () => {
            document.getElementById('new-images').value = urlInput.value.trim();
        });
    }

    // AI Generate (using pollinations.ai free image generation)
    const aiBtn = document.getElementById('ai-generate-btn');
    const aiInput = document.getElementById('ai-prompt-input');
    const aiPreview = document.getElementById('ai-preview');
    if (aiBtn && aiInput && aiPreview) {
        aiBtn.addEventListener('click', async () => {
            const prompt = aiInput.value.trim();
            if (!prompt) {
                showToast('Enter a description first', 'error');
                return;
            }
            aiPreview.innerHTML = '<div class="ai-generating"><i class="fas fa-spinner"></i><span>Generating...</span></div>';
            try {
                const encoded = encodeURIComponent(prompt);
                const imageUrl = `https://image.pollinations.ai/prompt/${encoded}?width=800&height=450&seed=${Math.floor(Math.random()*999999)}&nologo=true`;
                // Preload to verify
                const img = new Image();
                img.onload = () => {
                    aiPreview.innerHTML = `<img src="${imageUrl}" alt="AI generated">`;
                    document.getElementById('new-images').value = imageUrl;
                    showToast('AI image generated!', 'success');
                };
                img.onerror = () => {
                    aiPreview.innerHTML = '<span>Failed. Try again.</span>';
                    showToast('Image generation failed', 'error');
                };
                img.src = imageUrl;
            } catch (e) {
                aiPreview.innerHTML = '<span>Failed. Try again.</span>';
            }
        });
    }
}

// Start
document.addEventListener('DOMContentLoaded', init);